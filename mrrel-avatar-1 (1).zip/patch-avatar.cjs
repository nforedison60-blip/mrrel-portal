const fs=require('fs');let ok=true;
function edit(f,a,b){let s=fs.readFileSync(f,'utf8');if(s.includes(b))return;if(!s.includes(a)){console.log('missing in '+f);ok=false;return;}fs.writeFileSync(f,s.replace(a,b));}
const v='resources/views/customer/';
edit(v+'bookings.blade.php',`<div class="av" style="width: 64px; height: 64px; font-size: 24px;">{{ strtoupper(substr($providerName, 0, 1)) }}</div>`,`<x-provider-avatar :user-id="$providerUserId" :name="$providerName" :size="64" />`);
edit(v+'quotes.blade.php',`<div class="av">{{ strtoupper(substr($quote->provider_name, 0, 1)) }}</div>`,`<x-provider-avatar :user-id="$quote->provider_user_id" :name="$quote->provider_name" :size="44" />`);
edit(v+'quote-detail.blade.php',`<div class="av" style="width: 64px; height: 64px; font-size: 24px;">{{ $initial }}</div>`,`<x-provider-avatar :user-id="$quote->provider_user_id" :name="$quote->provider_name" :size="64" />`);
edit(v+'dashboard.blade.php',`<div class="av" style="width:60px;height:60px;font-size:24px;">{{ strtoupper(substr($providerName, 0, 1)) }}</div>`,`<x-provider-avatar :user-id="optional($bookedQuote)->provider_user_id" :name="$providerName" :size="60" />`);
console.log(ok?'DONE':'FAILED');
if(ok)try{fs.unlinkSync(__filename)}catch(e){}
