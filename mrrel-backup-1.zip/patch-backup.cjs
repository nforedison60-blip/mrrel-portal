const fs=require('fs');let ok=true;
function edit(f,a,b){let s=fs.readFileSync(f,'utf8');if(s.includes(b))return;if(!s.includes(a)){console.log('missing in '+f+': '+a.slice(0,70));ok=false;return;}fs.writeFileSync(f,s.replace(a,b));}
edit('routes/web.php',"require __DIR__.'/landlord-intro.php';","require __DIR__.'/landlord-intro.php';\nrequire __DIR__.'/backup.php';");
edit('resources/views/layouts/admin.blade.php',"                    ['Settings', 'admin.settings', ['admin.settings*']],","                    ['Settings', 'admin.settings', ['admin.settings*']],\n                    ['Backup', 'admin.backup', ['admin.backup*']],");
console.log(ok?'DONE':'FAILED');
if(ok)try{fs.unlinkSync(__filename)}catch(e){}
