const fs=require('fs');let ok=true;
function edit(f,pairs){let s=fs.readFileSync(f,'utf8');for(const [a,b] of pairs){if(s.includes(b))continue;if(!s.includes(a)){console.log('missing in '+f+': '+a.slice(0,70));ok=false;continue;}s=s.replace(a,b);}fs.writeFileSync(f,s);}

// 1. MrRel's bank account (FNB business account) and the proof-of-payment email
edit('config/mrrel.php',[
[`    'bank' => [
        'name'    => env('MRREL_BANK_NAME'),
        'holder'  => env('MRREL_BANK_HOLDER', 'MrRel'),
        'account' => env('MRREL_BANK_ACCOUNT'),
        'type'    => env('MRREL_BANK_TYPE', 'Cheque / Current'),
        'branch'  => env('MRREL_BANK_BRANCH'),
    ],`,
`    'bank' => [
        'name'    => env('MRREL_BANK_NAME', 'FNB (First National Bank)'),
        'holder'  => env('MRREL_BANK_HOLDER', 'MRREL (PTY) LTD'),
        'account' => env('MRREL_BANK_ACCOUNT', '63236576625'),
        'type'    => env('MRREL_BANK_TYPE', 'Gold Business Account'),
        'branch'  => env('MRREL_BANK_BRANCH', '203809'),
        'swift'   => env('MRREL_BANK_SWIFT', 'FIRNZAJJ'),
    ],

    // Where people email their proof of payment after paying by bank transfer
    'pop_email' => env('MRREL_POP_EMAIL', 'relocations@mrrel.co.za'),`]]);

// 2. the routes
edit('routes/web.php',[["require __DIR__.'/landlord-intro.php';","require __DIR__.'/landlord-intro.php';\nrequire __DIR__.'/bank.php';"]]);

// 3. the bank button creates the same pending record as Pay now, then opens the instructions
edit('app/Http/Controllers/Tenant/TenantPaymentController.php',[
["        return $this->ozowForm($payment, route('customer.matches'));",
"        if (request('method') === 'bank') {\n            return redirect()->route('bank.show', $payment->reference());\n        }\n\n        return $this->ozowForm($payment, route('customer.matches'));"],
["        return $this->ozowForm($payment, route('customer.shortlist'));",
"        if (request('method') === 'bank') {\n            return redirect()->route('bank.show', $payment->reference());\n        }\n\n        return $this->ozowForm($payment, route('customer.shortlist'));"]]);
edit('app/Http/Controllers/Landlord/LandlordIntroController.php',[
["        return $this->ozowForm($match);\n    }\n\n    // Back from the bank.",
"        if (request('method') === 'bank') {\n            return redirect()->route('bank.show', $match->introReference());\n        }\n\n        return $this->ozowForm($match);\n    }\n\n    // Back from the bank."]]);

// 4. the buttons
const B='<button type="submit" name="method" value="bank" class="btn g"';
edit('resources/views/customer/matches.blade.php',[
[`<button type="submit" class="btn">Pay R{{ number_format($fee, 0) }}</button>`,
`<button type="submit" class="btn">Pay R{{ number_format($fee, 0) }}</button>\n                    ${B}>Pay by bank transfer</button>`]]);
edit('resources/views/customer/_property_tenant.blade.php',[
[`<button type="submit" class="btn" style="width:100%; margin:0;">Pay R99</button>`,
`<button type="submit" class="btn" style="width:100%; margin:0;">Pay R99</button>\n                ${B} style="width:100%; margin:8px 0 0;">Pay by bank transfer</button>`]]);
edit('resources/views/customer/attendance.blade.php',[
[`<button type="submit" class="btn">Pay R{{ number_format($estimate['fee'], 2) }}</button>`,
`<button type="submit" class="btn">Pay R{{ number_format($estimate['fee'], 2) }}</button>\n            ${B}>Pay by bank transfer</button>`]]);
edit('resources/views/landlord/introductions.blade.php',[
[`<button type="submit" class="btn" style="margin:0;">Proceed and pay R{{ number_format($fee, 0) }}</button>`,
`<button type="submit" class="btn" style="margin:0;">Proceed and pay R{{ number_format($fee, 0) }}</button>\n                            ${B} style="margin:0;">Pay by bank transfer</button>`]]);
const REF="{{ route('bank.show', 'BKG-' . str_pad($BK->id, 4, '0', STR_PAD_LEFT)) }}";
edit('resources/views/payment/checkout.blade.php',[
[`        <p class="m sm" style="margin-top: 12px;"><a href="{{ route('customer.bookings', ['booking' => $booking->id]) }}" style="color:inherit;">Back to my booking</a></p>`,
`        <a href="${REF.replace('$BK','$booking')}" class="btn g" style="display:block; text-align:center; text-decoration:none; margin-top:10px;">Pay by bank transfer</a>\n        <p class="m sm" style="margin-top: 12px;"><a href="{{ route('customer.bookings', ['booking' => $booking->id]) }}" style="color:inherit;">Back to my booking</a></p>`]]);
edit('resources/views/customer/bookings.blade.php',[
[`class="btn w" style="text-align: center; text-decoration: none;">Pay now</a>`,
`class="btn w" style="text-align: center; text-decoration: none;">Pay now</a>\n                    <a href="${REF.replace('$BK','$booking')}" class="btn g w" style="text-align: center; text-decoration: none; margin-top: 8px;">Pay by bank transfer</a>`]]);
edit('resources/views/customer/tracking.blade.php',[
[`<a href="{{ route('payment.checkout', ['booking' => $booking->id]) }}" class="btn">Pay now</a>`,
`<a href="{{ route('payment.checkout', ['booking' => $booking->id]) }}" class="btn">Pay now</a>\n        <a href="${REF.replace('$BK','$booking')}" class="btn g" style="text-decoration:none;">Pay by bank transfer</a>`]]);

// 5. landlord invoices already list the bank details: add where to send proof of payment
edit('resources/views/landlord/invoice.blade.php',[
["Use the reference exactly as shown. MrRel marks the invoice as paid when the money reaches the account, and your receipt appears here.",
"Use the reference exactly as shown, then email your proof of payment to {{ config('mrrel.pop_email') }} with {{ $invoice->number }} in the subject. MrRel marks the invoice as paid when the money reaches the account, and your receipt appears here."]]);

// 6. admin menu
edit('resources/views/layouts/admin.blade.php',[
["                    ['Invoices', 'admin.invoices', ['admin.invoices*']],",
"                    ['Bank payments', 'admin.bank-payments', ['admin.bank-payments*']],\n                    ['Invoices', 'admin.invoices', ['admin.invoices*']],"]]);

console.log(ok?'DONE':'FAILED');
if(ok)try{fs.unlinkSync(__filename)}catch(e){}
