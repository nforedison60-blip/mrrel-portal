const fs=require('fs');
let ok=true;
function edit(f,pairs){let s=fs.readFileSync(f,'utf8');for(const [a,b] of pairs){if(s.includes(b))continue;if(!s.includes(a)){console.log('missing in '+f+': '+a.slice(0,50));ok=false;continue;}s=s.replace(a,b);}fs.writeFileSync(f,s);}
edit('routes/web.php',[["            'openDisputes' => Problem::where('status', 'In progress')->count(),\n        ]);\n    })->name('admin.dashboard');",
"            'openDisputes' => Problem::where('status', 'In progress')->count(),\n            'tenantsToMatch' => \\App\\Models\\RentalNeed::where('status', 'Open')->count(),\n            'payoutsToRecord' => \\App\\Models\\Booking::where('status', 'Paid')->whereNull('paid_out_at')->count(),\n        ]);\n    })->name('admin.dashboard');"]]);
edit('resources/views/admin/dashboard.blade.php',[
['<div class="big">5</div>','<div class="big">{{ $tenantsToMatch }}</div>'],
['<li>Build 3 shortlists</li>','<li>Match {{ $tenantsToMatch }} tenants</li>'],
['<li>Record 4 payouts</li>','<li>Record {{ $payoutsToRecord }} payouts</li>']]);
console.log(ok?'DONE':'FAILED');
if(ok)try{fs.unlinkSync(__filename)}catch(e){}
