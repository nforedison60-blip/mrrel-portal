const fs=require('fs'),path=require('path');
let bad=[],changed=[];

// 1. Make sure the email notifications are switched on (the earlier patch may not have been run)
const sp='app/Providers/AppServiceProvider.php';
if(!fs.existsSync(sp)) bad.push('missing '+sp);
else{
  let s=fs.readFileSync(sp,'utf8');
  if(!s.includes('Notifications::register')){
    const re=/public function boot\(\): void\s*\{/;
    if(!re.test(s)) bad.push('boot() not found in '+sp);
    else{ s=s.replace(re,m=>m+"\n        \\App\\Support\\Notifications::register(); // emails that tell people something happened\n"); fs.writeFileSync(sp,s); changed.push(sp); }
  }
}

// 2. Test users must have a verified email, like real users now need
function walk(d){return fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);}
for(const f of walk('tests').filter(f=>f.endsWith('.php'))){
  let s=fs.readFileSync(f,'utf8');
  if(/User::create\(/.test(s)){ fs.writeFileSync(f,s.replace(/\bUser::create\(/g,'User::factory()->create(')); changed.push(f); }
}

if(bad.length){console.log('FAILED',bad);process.exit(1);}
console.log('DONE, changed:',changed.join(', ')||'nothing');
try{fs.unlinkSync(__filename)}catch(e){}
