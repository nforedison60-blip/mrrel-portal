const fs=require('fs');
const f='app/Support/Notifications.php';
if(!fs.existsSync(f)){console.log('FAILED: '+f+' is missing');process.exit(1);}
let s=fs.readFileSync(f,'utf8');
if(s.includes('mrrel.notifications')){console.log('DONE (already applied)');}
else{
  const a=s.indexOf('    public static function register(): void');
  const b=s.indexOf('    // One email.');
  if(a<0||b<0||b<a){console.log('FAILED: could not find register() in '+f);process.exit(1);}
  const body=`    public static function register(): void
    {
        // Register once per application, and through the event system itself so it works at any point of start-up
        if (app()->bound('mrrel.notifications')) {
            return;
        }
        app()->instance('mrrel.notifications', true);

        // A tenant payment was confirmed (matching fee or viewing attendance)
        Event::listen('eloquent.updated: ' . TenantPayment::class, function (TenantPayment $payment) {
            if ($payment->wasChanged('status') && $payment->status === 'Paid') {
                self::tenantPaid($payment);
            }
        });

        // A landlord paid the introduction fee
        Event::listen('eloquent.updated: ' . PropertyMatch::class, function (PropertyMatch $match) {
            if ($match->wasChanged('intro_status') && $match->intro_status === 'Paid') {
                self::introductionPaid($match);
            }
        });

        // MrRel approved a property
        Event::listen('eloquent.updated: ' . Property::class, function (Property $property) {
            if ($property->wasChanged('status') && $property->status === 'Approved' && $property->getOriginal('status') === 'Draft') {
                self::propertyApproved($property);
            }
        });

        // MrRel verified a mover
        Event::listen('eloquent.updated: ' . Provider::class, function (Provider $provider) {
            if ($provider->wasChanged('verification_status') && $provider->verification_status === 'Verified') {
                self::providerVerified($provider);
            }
        });
    }

`;
  s=s.slice(0,a)+body+s.slice(b);
  if(!s.includes('use Illuminate\\Support\\Facades\\Event;')) s=s.replace('use Illuminate\\Support\\Facades\\Log;','use Illuminate\\Support\\Facades\\Event;\nuse Illuminate\\Support\\Facades\\Log;');
  fs.writeFileSync(f,s);
  console.log('DONE');
}
// make sure it is switched on at start-up
const sp='app/Providers/AppServiceProvider.php';
let p=fs.readFileSync(sp,'utf8');
if(!p.includes('Notifications::register')){
  const re=/public function boot\(\)(: void)?\s*\{/;
  if(!re.test(p)){console.log('FAILED: boot() not found');process.exit(1);}
  fs.writeFileSync(sp,p.replace(re,m=>m+"\n        \\App\\Support\\Notifications::register(); // emails that tell people something happened\n"));
}
try{fs.unlinkSync(__filename)}catch(e){}
