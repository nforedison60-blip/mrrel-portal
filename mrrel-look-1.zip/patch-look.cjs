const fs=require('fs'),path=require('path');
let changed=0;
function walk(d){return fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);}
const files=[...walk('resources/views'),'public/css/mrrel-ui.css'].filter(f=>fs.existsSync(f)&&/\.(php|css)$/.test(f));
const colour=[[/#14A0AC/gi,'#2F7FD1'],[/#0F4C5C/gi,'#0A3A7A'],[/#EAF6F7/gi,'#EAF1FA'],[/#E9F3F4/gi,'#E6EEF8'],[/#DCEEF0/gi,'#DCE8F6'],[/#FFD263/gi,'#FFB070'],[/#FFE08A/gi,'#FFC99A'],[/#FFD66E/gi,'#FFB878'],[/#E7A516/gi,'#E85F00'],[/#D49410/gi,'#C95000'],[/#FCEBB0/gi,'#FFE3CC'],[/#FFF6D8/gi,'#FFF0E5'],[/#10243A/gi,'#003068'],[/#0E7C86/gi,'#0A4C9A'],[/#E3F1F2/gi,'#E6EEF8'],[/#0A5C64/gi,'#003068'],[/#F4B731/gi,'#FF7A1A'],[/#FDF1CC/gi,'#FFF0E5'],[/rgba\(14,124,134/g,'rgba(10,76,154'],[/rgba\(244,183,49/g,'rgba(255,122,26'],[/rgba\(16,36,58/g,'rgba(0,48,104'],[/Bricolage(\+| )Grotesque/g,(m,p)=>p==='+'?'Montserrat':'Montserrat'],[/\bFigtree\b/g,'Open Sans']];
for(const f of files){let s=fs.readFileSync(f,'utf8'),o=s;
  for(const [a,b] of colour) s=s.replace(a,b);
  s=s.replace(/family=Montserrat:wght@700;800&family=Open\+Sans:wght@400;500;600;700/g,'family=Montserrat:wght@600;700;800&family=Open+Sans:wght@400;500;600;700');
  s=s.replace(/family=Montserrat:wght@700;800&family=Open Sans:wght@400;500;600;700/g,'family=Montserrat:wght@600;700;800&family=Open+Sans:wght@400;500;600;700');
  if(f.includes('resources/views/layouts/')){
    const role={admin:'Admin',app:'Customer',customer:'Customer',landlord:'Landlord',provider:'Mover'}[path.basename(f).replace('.blade.php','')];
    const home={admin:"admin.dashboard",app:"customer.dashboard",customer:"customer.dashboard",landlord:"landlord.properties",provider:"provider.dashboard"}[path.basename(f).replace('.blade.php','')];
    if(role){
      s=s.replace(/<div class="logo"><i><\/i>MrRel<\/div>\s*<div class="sw" id="sw">[\s\S]*?<\/div>/,
        `<a class="logo" href="{{ route('${home}') }}"><img src="{{ asset('images/mrrel-logo.png') }}" alt="MrRel"></a>\n        <span class="role">${role}</span>`);
      s=s.replace(/\s*<span style="opacity:\.85;font-size:13px">Example data<\/span>/,'');
      s=s.replace(/border:1px solid rgba\(255,255,255,0\.3\); color:#fff;/g,'border:1px solid #D5DEE6; color:#003068;');
    } else if(path.basename(f)==='guest.blade.php'){
      s=s.replace('<div class="logo"><i></i>MrRel</div>',`<div class="logo"><img src="{{ asset('images/mrrel-logo.png') }}" alt="MrRel"></div>`);
    }
    if(!s.includes('mrrel-brand.css')) s=s.replace(/^([ \t]*)(<link rel="stylesheet" href="\{\{ asset\('css\/mrrel-ui\.css'\) \}\}[^\n]*)$/m,(m,ws,l)=>ws+l+'\n'+ws+`<link rel="stylesheet" href="{{ asset('css/mrrel-brand.css') }}?v={{ @filemtime(public_path('css/mrrel-brand.css')) }}">`);
  }
  if(s!==o){fs.writeFileSync(f,s);changed++;}
}
// ui.css top bar was forced dark: let the brand file win by neutralising it
let u=fs.readFileSync('public/css/mrrel-ui.css','utf8');
const nu=u.replace(/^\.top\{background:linear-gradient[^\n]*\n/m,'.top{}\n');
if(nu!==u){fs.writeFileSync('public/css/mrrel-ui.css',nu);changed++;}
const bad=[];
for(const f of walk('resources/views/layouts')){const s=fs.readFileSync(f,'utf8');if(/Example data|id="sw"/.test(s))bad.push(f);if(/layouts\/(admin|app|customer|landlord|provider|guest)\.blade/.test(f)&&!s.includes('mrrel-brand.css'))bad.push('nobrand '+f);}
if(bad.length){console.log('FAILED',bad);process.exit(1);}
console.log('DONE, files changed:',changed);
try{fs.unlinkSync(__filename)}catch(e){}
