const fs=require('fs');let ok=true;
function edit(f,pairs){let s=fs.readFileSync(f,'utf8');for(const [a,b] of pairs){if(s.includes(b))continue;if(!s.includes(a)){console.log('missing in '+f+': '+a.slice(0,70));ok=false;continue;}s=s.replace(a,b);}fs.writeFileSync(f,s);}
edit('public/js/mrrel-ui.js',[
["      help: '<circle",
 "      search: '<circle cx=\"11\" cy=\"11\" r=\"6.5\"/><path d=\"M16 16l4.5 4.5\"/>',\n      help: '<circle"],
["      if (/home|overview/.test(t)) return 'home';\n      if (/find a place|search/.test(t)) return 'place';",
 "      if (/browse|search/.test(t)) return 'search';\n      if (/find/.test(t)) return 'place';\n      if (/home|overview/.test(t)) return 'home';"]]);
edit('resources/views/layouts/app.blade.php',[["'short' => 'Homes'","'short' => 'Find'"]]);
let css=fs.readFileSync('public/css/mrrel-brand.css','utf8');
if(!css.includes('/* mobile bottom bar */')){css+=`
/* mobile bottom bar: every item has an icon and the labels line up */
@media (max-width:860px){
  .mb a{justify-content:flex-start !important;padding:9px 2px 8px !important;font-size:12px !important;line-height:1.2;white-space:nowrap;min-height:58px}
  .mb a .mi{flex:none}
}
`.replace('/* mobile bottom bar:','/* mobile bottom bar */\n/*');fs.writeFileSync('public/css/mrrel-brand.css',css);}
console.log(ok?'DONE':'FAILED');
if(ok)try{fs.unlinkSync(__filename)}catch(e){}
