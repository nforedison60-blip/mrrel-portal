const fs=require('fs');let ok=true;
function edit(f,a,b){let s=fs.readFileSync(f,'utf8');if(s.includes(b))return;if(!s.includes(a)){console.log('missing in '+f+': '+a.slice(0,70));ok=false;return;}fs.writeFileSync(f,s.replace(a,b));}
edit('app/Support/Notifications.php',"    // MrRel sent a tenant their matches (called from the admin matching screen)",
`    // Every admin hears about a new account the moment someone registers
    public static function newAccount(User $user): void
    {
        try {
            $role = match ($user->role) {
                'Provider' => 'Mover (provider)',
                'Landlord' => 'Landlord',
                default    => 'Customer',
            };
            $lines = [
                ($user->name ?: 'Someone') . ' just created a MrRel account.',
                'Role: ' . $role,
                'Email: ' . $user->email,
                'Phone: ' . ($user->phone ?: 'not given'),
                'They still need to confirm their email before they can use the portal.',
            ];
            if ($user->role === 'Provider') {
                $lines[] = 'They will apply as a mover next. You will see the application under Approvals.';
            }
            foreach (User::where('role', 'Admin')->whereNotNull('email')->pluck('email')->unique() as $to) {
                self::send($to, 'New ' . strtolower($role) . ' account: ' . $user->name, 'New account on MrRel', $lines, 'Open users', self::link('admin.users'));
            }
        } catch (\\Throwable $e) {
            Log::warning('New account notice failed', ['error' => $e->getMessage()]);
        }
    }

    // MrRel sent a tenant their matches (called from the admin matching screen)`);
edit('app/Http/Controllers/Auth/RegisteredUserController.php',"        event(new Registered($user));","        event(new Registered($user));\n\n        \\App\\Support\\Notifications::newAccount($user);");
console.log(ok?'DONE':'FAILED');
if(ok)try{fs.unlinkSync(__filename)}catch(e){}
