const fs=require('fs');let ok=true;
function edit(f,pairs){let s=fs.readFileSync(f,'utf8');for(const [a,b] of pairs){if(s.includes(b))continue;if(!s.includes(a)){console.log('missing in '+f+': '+a.slice(0,70));ok=false;continue;}s=s.replace(a,b);}fs.writeFileSync(f,s);}
edit('resources/views/provider/profile.blade.php',[
["<label class=\"k\">ID Document (PDF/Image)","<label class=\"k\">ID or passport (PDF/Image)"],
["View Uploaded ID</a>","View uploaded ID or passport</a>"],
["'Photo matches ID' =>","'Photo matches ID or passport' =>"],
["'ID' => $hasId,","'ID or passport' => $hasId,"],
["                        <tr><td>Insurance document</td><td><span class=\"chip {{ $isVerified ? 'ok' : 'wn' }}\">{{ $isVerified ? 'Verified' : 'Pending' }}</span></td></tr>\n",""]]);
edit('resources/views/admin/providers.blade.php',[
["'id_image_path' => 'ID photo', 'id_document' => 'ID document',","'id_image_path' => 'ID photo', 'id_document' => 'ID or passport',"]]);
console.log(ok?'DONE':'FAILED');
if(ok)try{fs.unlinkSync(__filename)}catch(e){}
