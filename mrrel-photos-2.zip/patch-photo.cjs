const fs=require('fs');let ok=true;
function edit(f,pairs){let s=fs.readFileSync(f,'utf8');for(const [a,b] of pairs){if(s.includes(b))continue;if(!s.includes(a)){console.log('missing in '+f+': '+a.slice(0,60));ok=false;continue;}s=s.split(a).join(b);}fs.writeFileSync(f,s);}
// 1. route that streams the photo through the app (works whether or not the bucket is public)
edit('routes/web.php',[["// Opens a provider document through a short-lived link.",
`// Provider profile and vehicle photos, served by the app itself so they show even when the bucket link is not public.
Route::get('/provider-photo/{provider}/{kind}', function (Provider $provider, string $kind) {
    $path = $kind === 'vehicle' ? $provider->vehicle_image_path : ($kind === 'profile' ? $provider->image_path : null);
    abort_unless($path, 404);
    try {
        $disk = Storage::disk('s3');
        abort_unless($disk->exists($path), 404);
        return response($disk->get($path), 200, [
            'Content-Type'  => $disk->mimeType($path) ?: 'image/jpeg',
            'Cache-Control' => 'private, max-age=3600',
        ]);
    } catch (\\Throwable $e) {
        abort(404);
    }
})->middleware(['auth'])->name('provider.photo');

// Opens a provider document through a short-lived link.`]]);
const P="{{ route('provider.photo', [$provider->id, '";
edit('resources/views/provider/profile.blade.php',[
["{{ Storage::disk('s3')->url($provider->image_path) }}",P+"profile']) }}"],
["{{ Storage::disk('s3')->url($provider->vehicle_image_path) }}",P+"vehicle']) }}"]]);
edit('resources/views/admin/providers.blade.php',[
["{{ Storage::disk('s3')->url($provider->image_path) }}",P+"profile']) }}"],
["{{ Storage::disk('s3')->url($provider->vehicle_image_path) }}",P+"vehicle']) }}"]]);
edit('resources/views/provider/dashboard.blade.php',[
["\\Illuminate\\Support\\Facades\\Storage::disk('s3')->url($provider->image_path)","route('provider.photo', [$provider->id, 'profile'])"]]);
// 2. customer avatar uses the same route
edit('resources/views/components/provider-avatar.blade.php',[
["$photo = \\Illuminate\\Support\\Facades\\Storage::disk('s3')->url($p->image_path);","$photo = route('provider.photo', [$p->id, 'profile']);"]]);
console.log(ok?'DONE':'FAILED');
if(ok)try{fs.unlinkSync(__filename)}catch(e){}
