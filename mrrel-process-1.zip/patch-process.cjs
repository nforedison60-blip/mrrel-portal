const fs=require('fs');
const f='resources/views/landlord/introductions.blade.php';
let s=fs.readFileSync(f,'utf8');
if(s.includes("landlord._process")){console.log('DONE (already applied)');}
else{
  const m=s.match(/^.*MrRel finds tenants whose needs match your property.*$/m);
  if(!m){console.log('FAILED: anchor not found in '+f);process.exit(1);}
  s=s.replace(m[0],m[0]+"\n\n    @include('landlord._process')");
  fs.writeFileSync(f,s);console.log('DONE');
}
try{fs.unlinkSync(__filename)}catch(e){}
