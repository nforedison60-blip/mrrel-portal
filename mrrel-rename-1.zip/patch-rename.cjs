const fs=require('fs');
const edits={
 'resources/views/customer/dashboard.blade.php':[["Find a place</a>","Browse homes</a>"]],
 'resources/views/customer/shortlist.blade.php':[["Find a place</a>","Browse homes</a>"]],
 'resources/views/customer/fees.blade.php':[["Find a place</a>","Browse homes</a>"]],
 'resources/views/customer/search.blade.php':[["<h1>Find me a place</h1>","<h1>Browse homes</h1>"],["Search for available properties to rent.","A quick look at homes available now. To get matched with homes that fit you, go to Find a home."]],
 'resources/views/layouts/app.blade.php':[["'label' => 'Find a place', 'short' => 'Places'","'label' => 'Browse homes', 'short' => 'Browse'"]],
 'resources/views/layouts/customer.blade.php':[[">Find a place</a>",">Browse homes</a>"]],
};
let bad=[];
for(const [f,list] of Object.entries(edits)){
  if(!fs.existsSync(f)){bad.push('missing '+f);continue;}
  let s=fs.readFileSync(f,'utf8'),o=s;
  for(const [a,b] of list){ if(s.includes(a)) s=s.split(a).join(b); else if(!s.includes(b)) bad.push(f+' : '+a); }
  if(s!==o) fs.writeFileSync(f,s);
}
if(bad.length){console.log('FAILED',bad);process.exit(1);}
console.log('DONE');
try{fs.unlinkSync(__filename)}catch(e){}
