const fs=require('fs');
let bad=[];
function edit(f,fn){ if(!fs.existsSync(f)){bad.push('missing '+f);return;} const o=fs.readFileSync(f,'utf8'); const n=fn(o); if(n===null){bad.push('anchor not found in '+f);return;} if(n!==o) fs.writeFileSync(f,n); }

// 1. The User model must ask for verified emails
edit('app/Models/User.php',s=>{
  if(s.includes('MustVerifyEmail')) return s;
  if(!s.includes('class User extends Authenticatable')) return null;
  s=s.replace('use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;','use Illuminate\\Contracts\\Auth\\MustVerifyEmail;\nuse Illuminate\\Database\\Eloquent\\Factories\\HasFactory;');
  return s.replace('class User extends Authenticatable','class User extends Authenticatable implements MustVerifyEmail');
});

// 2. Every role area (customer, landlord, provider, admin) now needs a verified email
edit('app/Http/Middleware/EnsureRole.php',s=>{
  if(s.includes('verification.notice')) return s;
  const a="        if (! in_array($user->role, $roles, true)) {";
  if(!s.includes(a)) return null;
  return s.replace(a,"        if (! $user->hasVerifiedEmail()) {\n            return redirect()->route('verification.notice');\n        }\n\n"+a);
});

// 3. After registering, send people to the 'check your email' page
edit('app/Http/Controllers/Auth/RegisteredUserController.php',s=>{
  if(s.includes("route('verification.notice')")) return s;
  const re=/        if \(\$user->role === 'Provider'\) \{[\s\S]*?return redirect\(\)->route\('customer\.dashboard'\);\n/;
  if(!re.test(s)) return null;
  return s.replace(re,"        return redirect()->route('verification.notice');\n");
});

// 4. Pages outside a role area (payments, documents, dashboard) need it too
edit('routes/web.php',s=>{
  let n=s;
  n=n.replace("})->middleware(['auth'])->name('dashboard');","})->middleware(['auth', 'verified'])->name('dashboard');");
  n=n.replace("})->middleware('auth')->name('documents.show');","})->middleware(['auth', 'verified'])->name('documents.show');");
  n=n.replace(/Route::middleware\(\['auth'\]\)->group\(function \(\) \{(\s*\n\s*\n?\s*\/\/ PAYMENT ROUTES)/,"Route::middleware(['auth', 'verified'])->group(function () {$1");
  if(!n.includes("'dashboard');") || !n.includes("['auth', 'verified'])->group")) return null;
  return n;
});

if(bad.length){console.log('FAILED',bad);process.exit(1);}
console.log('DONE');
try{fs.unlinkSync(__filename)}catch(e){}
