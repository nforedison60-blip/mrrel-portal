const fs=require('fs');let ok=true;
function edit(f,a,b){let s=fs.readFileSync(f,'utf8');if(s.includes(b))return;if(!s.includes(a)){console.log('missing in '+f+': '+a.slice(0,60));ok=false;return;}fs.writeFileSync(f,s.replace(a,b));}
// 1. the link opens for the right person even if they are not logged in, or open it in another browser
fs.writeFileSync('app/Http/Controllers/Auth/VerifyEmailController.php',`<?php

namespace App\\Http\\Controllers\\Auth;

use App\\Http\\Controllers\\Controller;
use App\\Models\\User;
use Illuminate\\Auth\\Events\\Verified;
use Illuminate\\Http\\RedirectResponse;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\Auth;

class VerifyEmailController extends Controller
{
    /**
     * Verify the email from the link in the message (the link itself is signed, so no login is needed),
     * then sign the person in and take them to their dashboard.
     */
    public function __invoke(Request $request, string $id, string $hash): RedirectResponse
    {
        $user = User::findOrFail($id);

        abort_unless(hash_equals(sha1($user->getEmailForVerification()), $hash), 403);

        if (! $user->hasVerifiedEmail() && $user->markEmailAsVerified()) {
            event(new Verified($user));
        }

        Auth::login($user);
        $request->session()->regenerate();

        return redirect(route('dashboard', absolute: false).'?verified=1')
            ->with('success', 'Your email is verified. Welcome to MrRel!');
    }
}
`);
// 2. take the verify route out of the login-only group
let a=fs.readFileSync('routes/auth.php','utf8');
const old=`    Route::get('verify-email/{id}/{hash}', VerifyEmailController::class)
        ->middleware(['signed', 'throttle:6,1'])
        ->name('verification.verify');

`;
if(a.includes(old)){a=a.replace(old,'');a=a.replace("Route::middleware('auth')->group(function () {","// The emailed link is signed, so it works even when the person is not logged in\nRoute::get('verify-email/{id}/{hash}', VerifyEmailController::class)\n    ->middleware(['signed', 'throttle:6,1'])\n    ->name('verification.verify');\n\nRoute::middleware('auth')->group(function () {");fs.writeFileSync('routes/auth.php',a);}
else if(!a.includes("// The emailed link is signed")){console.log('missing route block');ok=false;}
// 3. Laravel Cloud sits behind a proxy: trust it so the signed link is checked as https
edit('bootstrap/app.php',"        $middleware->validateCsrfTokens(except: ['payment/notify']);","        $middleware->trustProxies(at: '*');\n        $middleware->validateCsrfTokens(except: ['payment/notify']);");
edit('app/Providers/AppServiceProvider.php',"        \\App\\Support\\Notifications::register(); // emails that tell people something happened","        \\App\\Support\\Notifications::register(); // emails that tell people something happened\n\n        // Links in emails (verify, reset) must be https on the live site or their signature fails with Forbidden\n        if (! app()->environment(['local', 'testing'])) {\n            \\Illuminate\\Support\\Facades\\URL::forceScheme('https');\n        }");
console.log(ok?'DONE':'FAILED');
if(ok)try{fs.unlinkSync(__filename)}catch(e){}
